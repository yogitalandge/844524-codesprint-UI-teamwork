let Appoinment = [] ;
function placeapp(){

    var appoint={
      
      FirstName:document.getElementById("fname").value+""+document.getElementById("lname").value,
    Address:document.getElementById("addr").value+""+document.getElementById("state").value,
    City:document.getElementById("city").value,
    Phone:document.getElementsByClassName("mob").value,
    Package:document.getElementById("package").value,
    TrainerPref:document.getElementById("trainerpref").value
   
    };
    if(Appoinment.FirstName !=="" && appoint.Address !==""&& appoint.City!==""&& appoint.Phone!==""&& appoint.Package!==""&& appoint.TrainerPref!==""){
        Appoinment=JSON.parse(localStorage.getItem("appoint")) || [];
        Appoinment.push(appoint);
        localStorage.setItem("appoint",JSON.stringify( Appoinment));
        window.open('viewAppoinment.html');
    }
}
  
  /* function Validation() {
    var regex = /^[a-zA-Z\s]+$/;
    var mailformat = /^w+([.-]?w+)*@w+([.-]?w+)*(.w{2,3})+$/;  
    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var age = document.getElementById('numb').value;
    var pin= document.getElementById('pin').value;
    
      
       
    if(fname == "") {
       alert(" First name cant be blank!")
    }
    else if(regex.test(fname) === false) {
           alert("First name contains only alphabets!!!");
           return false;
        } 
          
    if(lname == "") {
       alert("last name cant be blank!")
    } 
    else if(regex.test(lname) === false) {
           alert("last name contains only alphabets!!!");
           return false;
        } 
    
    if (isNaN(age) || age < 18 || age > 60)
    { 
      alert("The age must be in between 18 to 60 only!!!");
      return false;
    }
    
    if (isNaN(age) || age < 18 || age > 60)
    { 
      alert("The age must be in between 18 to 60 only!!!");
      return false;
    }
  }     */